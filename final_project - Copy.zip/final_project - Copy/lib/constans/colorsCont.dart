import 'package:flutter/material.dart';

const bottomColor=   Color.fromARGB(255, 95, 128, 105); 
   const Appbarr= Color.fromARGB(255, 209, 222, 209);  
   const colorTextBottom=Color.fromARGB(207, 255, 255, 255);   